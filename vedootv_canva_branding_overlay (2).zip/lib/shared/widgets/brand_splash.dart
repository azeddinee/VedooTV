import 'package:material_ui/material_ui.dart';

/// Brand ink, the splash and adaptive-icon background.
const kBrandInk = Color(0xFF0A0A12);

/// Mirrors the native splash while the app initializes.
class BrandSplash extends StatelessWidget {
  const BrandSplash({super.key});

  @override
  Widget build(BuildContext context) {
    return const ColoredBox(
      color: kBrandInk,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Image(
            image: AssetImage('assets/images/logo_mark.png'),
            width: 256,
            height: 256,
            fit: BoxFit.contain,
          ),
          Positioned(
            bottom: 48,
            child: Image(
              image: AssetImage('assets/images/wordmark.png'),
              width: 230,
              height: 80,
              fit: BoxFit.contain,
            ),
          ),
        ],
      ),
    );
  }
}

# VedooTV brand assets

The artwork in `source/` is exported from the approved Canva designs and is
the source of truth for the app's visual identity.

- `source/vedoo_app_icon.png`: exact square app icon artwork
- `source/vedoo_mark.png`: standalone transparent V mark
- `source/vedootv_wordmark.png`: transparent V + `vedoo.tv` wordmark

`export.py` prepares the Android launcher/adaptive icons, splash artwork,
in-app logo, Android TV banner, notification glyph and README icon from those
three source PNGs. The Flutter workflow then runs:

```sh
python3 assets/branding/export.py
dart run flutter_launcher_icons
dart run flutter_native_splash:create
```

The standalone V is used where a compact mark is needed; the complete
wordmark is used for the in-app/native splash branding and TV banner.

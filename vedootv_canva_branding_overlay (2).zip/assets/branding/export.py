"""Generate VedooTV app artwork from the original Canva PNG exports.

Source artwork lives in assets/branding/source/. The script prepares the
launcher icon, adaptive icon layers, splash artwork, in-app logo, Android TV
banner, notification glyph and README icon. Run before Flutter icon/splash
generators.
"""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
BR = ROOT / "assets/branding"
SRC = BR / "source"
PNG = BR / "png"
IMG = ROOT / "assets/images"
RES = ROOT / "android/app/src/main/res"


def load(name):
    return Image.open(SRC / name).convert("RGBA")


def trim(im):
    box = im.getchannel("A").getbbox()
    return im.crop(box) if box else im


def contain(im, size, max_box=None):
    im = trim(im.copy())
    im.thumbnail(max_box or size, Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", size, (0, 0, 0, 0))
    canvas.alpha_composite(im, ((size[0] - im.width) // 2,
                                (size[1] - im.height) // 2))
    return canvas


def save(im, path, size=None):
    if size:
        im = im.resize(size, Image.Resampling.LANCZOS)
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path, optimize=True)
    print(f"wrote {path.relative_to(ROOT)} {im.size}")


mark = load("vedoo_mark.png")
wordmark = trim(load("vedootv_wordmark.png"))
icon = load("vedoo_app_icon.png")

# The Canva app icon is almost square; crop the 11px excess evenly.
w, h = icon.size
side = min(w, h)
icon = icon.crop(((w-side)//2, (h-side)//2,
                  (w+side)//2, (h+side)//2))
save(icon, PNG / "app_icon.png", (1024, 1024))

# Android adaptive icon: preserve the real V artwork inside the safe zone.
foreground = contain(mark, (1024, 1024), (650, 650))
save(foreground, PNG / "icon_foreground.png")
mono = Image.new("RGBA", (1024, 1024), (255, 255, 255, 0))
mono.putalpha(foreground.getchannel("A"))
save(mono, PNG / "icon_monochrome.png")
save(Image.new("RGB", (1024, 1024), (10, 12, 48)),
     PNG / "icon_background.png")

# Exact Canva mark and wordmark for in-app branding.
save(contain(mark, (512, 512), (470, 470)), IMG / "logo_mark.png")
wordmark_out = wordmark.resize(
    (1200, round(1200 * wordmark.height / wordmark.width)),
    Image.Resampling.LANCZOS)
save(wordmark_out, IMG / "wordmark.png")

# Native splash uses the mark only; the wordmark is supplied separately.
save(contain(mark, (1152, 1152), (850, 850)),
     PNG / "splash_mark.png")

# Android TV / Fire TV banner with the exact supplied wordmark.
banner = Image.new("RGBA", (1280, 720), (8, 9, 20, 255))
banner_logo = wordmark.copy()
banner_logo.thumbnail((1040, 380), Image.Resampling.LANCZOS)
banner.alpha_composite(
    banner_logo, ((1280-banner_logo.width)//2, (720-banner_logo.height)//2))
banner = banner.convert("RGB")
save(banner, RES / "drawable/tv_banner.png", (320, 180))
save(banner, RES / "drawable-xhdpi/tv_banner.png", (640, 360))

# White monochrome notification glyph, preserving the Canva mark silhouette.
stat = Image.new("RGBA", (1024, 1024), (255, 255, 255, 0))
stat.putalpha(foreground.getchannel("A"))
for density, px in [("mdpi", 24), ("hdpi", 36), ("xhdpi", 48),
                    ("xxhdpi", 72), ("xxxhdpi", 96)]:
    save(stat, RES / f"drawable-{density}/ic_stat_open_iptv.png", (px, px))

save(icon, ROOT / "docs/images/icon.png", (256, 256))
